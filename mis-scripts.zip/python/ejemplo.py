# Ejemplo de script Python
