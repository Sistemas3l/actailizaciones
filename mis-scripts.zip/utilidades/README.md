# Utilidades

Carpeta para scripts y funciones de uso general.
