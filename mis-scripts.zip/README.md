# Mis Scripts Administrativos

Este repositorio contiene scripts para administración de sistemas y automatización de tareas.

## Carpetas

- `powershell/` : Scripts para Windows, como apertura de puertos en el firewall.
- `python/` : Scripts en Python para automatización, reportes, etc.
- `utilidades/` : Funciones y scripts de uso general.

## Script destacado

### abrir_puertos_compaqi.ps1

Este script abre los puertos necesarios en el **Firewall de Windows** para los sistemas CONTPAQi®:

- TCP: 1099, 1138, 1139, 1775, 2003, 9005, 7653, 135, 139, 445, 1433, 9080, 9081, 9082, 9047, 9020, 9083
- UDP: 1434

**Uso:**

1. Abrir PowerShell como administrador.
2. Navegar a la carpeta donde se encuentra el script:
   ```powershell
   cd ruta\al\repositorio\powershell
   ```
3. Ejecutar:
   ```powershell
   .\abrir_puertos_compaqi.ps1
   ```
4. Verificar que los puertos estén abiertos.

> Nota: Ajusta los puertos según tu instalación si es necesario.
