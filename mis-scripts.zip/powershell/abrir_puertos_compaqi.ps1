# Script para abrir puertos de CONTPAQi® en el Firewall de Windows

$puertosTCP = @(1099, 1138, 1139, 1775, 2003, 9005, 7653, 135, 139, 445, 1433, 9080, 9081, 9082, 9047, 9020, 9083)
$puertosUDP = @(1434)

function Agregar-ReglaFirewall {
    param (
        [string]$nombreRegla,
        [int[]]$puertos,
        [string]$protocolo
    )

    foreach ($puerto in $puertos) {
        $reglaNombre = "$nombreRegla $puerto"
        Write-Host "Creando regla: $reglaNombre"
        New-NetFirewallRule -DisplayName $reglaNombre -Direction Inbound -Protocol $protocolo -LocalPort $puerto -Action Allow -Profile Any
    }
}

Agregar-ReglaFirewall -nombreRegla "CONTPAQi TCP" -puertos $puertosTCP -protocolo "TCP"
Agregar-ReglaFirewall -nombreRegla "CONTPAQi UDP" -puertos $puertosUDP -protocolo "UDP"

Write-Host "Todas las reglas de firewall para CONTPAQi® han sido creadas correctamente."
